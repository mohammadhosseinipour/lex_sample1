idk whats wrong with Q2.l that i wrote . i checked every thing i could imagine. still it didnt work
but b.l code works correctly
i found this code on geeksforgeeks website . i almost understand 80% of it but not all of it .
i would appritiate it if you could currect my Q2.l code or tell me whats wrong with it.
thanks.